import java.util.*;
public class Main {
    static int max(int x, int y ) 
    {
        return(x>y)?x:y;
    }
     static int min(int x, int y ) 
    {
        return(x<y)?x:y;
    }
    static public void main(String[] args)
    {
        Scanner sc = new Scanner (System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        int d = sc.nextInt();
        int mx = max(max(a,b),max(c,d));
        int mn = min(min(a,b),min(c,d));
        int mid1 = min(max(a,b),max(c,d));
        int mid2 = max(min(a,b),min(c,d));
        if(mid1>mid2)
        {
            int t = mid1;
            mid1 = mid2;
            mid2=t;
        }
        System.out.println(mn+ "<" +mid1+ "<" +mid2+ "<" +mx);
    }
}